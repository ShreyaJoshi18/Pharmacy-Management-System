import java.util.Date;

public class Drug {
    private String name;
    private int ID;
    private int discount;
    private String companyName;
    private Date expiry;
    private int mrp;
    private boolean prescibed;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getDiscount() {
        return discount;
    }

    public void setDiscount(int discount) {
        this.discount = discount;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Date getExpiry() {
        return expiry;
    }

    public void setExpiry(Date expiry) {
        this.expiry = expiry;
    }

    public int getMrp() {
        return mrp;
    }

    public void setMrp(int mrp) {
        this.mrp = mrp;
    }

    public boolean isPrescibed() {
        return prescibed;
    }

    public void setPrescibed(boolean prescibed) {
        this.prescibed = prescibed;
    }
    
    
}
