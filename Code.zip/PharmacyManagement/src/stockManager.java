
public class stockManager {
    private int stockid;
    private int did;
    private int remqty;

    public int getStockid() {
        return stockid;
    }

    public void setStockid(int stockid) {
        this.stockid = stockid;
    }

    public int getDid() {
        return did;
    }

    public void setDid(int did) {
        this.did = did;
    }

    public int getRemqty() {
        return remqty;
    }

    public void setRemqty(int remqty) {
        this.remqty = remqty;
    }
    
}
