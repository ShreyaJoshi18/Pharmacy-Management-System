import java.sql.*;
import javax.swing.JOptionPane;
import java.util.ArrayList;

public class DBManager {

    private static final String DBDRIVER = "com.mysql.jdbc.Driver";
    private static final String DBURL = "jdbc:mysql://localhost/pharmacy_management";
    private static final String DBUSER = "root";
    private static final String DBPASSWORD = "root";

    static {
        try {
            Class.forName(DBDRIVER);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Cannot connect to the data base server", "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
    }

    public static boolean insertDrug(Drug drug) {
        try (Connection con = DriverManager.getConnection(DBURL, DBUSER, DBPASSWORD)) {
            PreparedStatement st = con.prepareStatement("insert into drug (name, discount, company_name, mrp, prescribed) values (?, ?, ?, ?, ?)");

            st.setString(1, drug.getName());
            st.setInt(2, drug.getDiscount());
            st.setString(3, drug.getCompanyName());
            st.setInt(4, drug.getMrp());
            st.setBoolean(5, drug.isPrescibed());
            st.executeUpdate();
            return true;
        } catch (Exception ex) {
            System.out.println(ex);
            return false;
        }
    }

    public static ArrayList<String> getCompanyNamesByDrugName(String name) {
        ArrayList<String> list = new ArrayList<>();
        try (Connection con = DriverManager.getConnection(DBURL, DBUSER, DBPASSWORD)) {
            PreparedStatement st = con.prepareStatement("select company_name from drug where name like ?");

            st.setString(1, name + "%");
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                String s = rs.getString(1);
                list.add(s);
            }
            return list;
        } catch (Exception ex) {
            System.out.println(ex);
            return list;
        }
    }

    public static ArrayList<String> getAllDrugs() {
        ArrayList<String> list = new ArrayList<>();
        try (Connection con = DriverManager.getConnection(DBURL, DBUSER, DBPASSWORD)) {
            PreparedStatement st = con.prepareStatement("select distinct(name) from drug");

            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                String s = rs.getString(1);
                list.add(s);
            }
            return list;
        } catch (Exception ex) {
            System.out.println(ex);
            return list;
        }
    }

    public static int getDrugIdByNameAndCompanyName(String name, String companyName) {
        int s = -1;
        try (Connection con = DriverManager.getConnection(DBURL, DBUSER, DBPASSWORD)) {
            PreparedStatement st = con.prepareStatement("select id from drug where name = ? and company_name = ? limit 1");
            st.setString(1, name);
            st.setString(2, companyName);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                s = rs.getInt(1);
            }
            return s;
        } catch (Exception ex) {
            System.out.println(ex);
            return s;
        }
    }

    public static boolean insertSale(Sales sale) {
        try (Connection con = DriverManager.getConnection(DBURL, DBUSER, DBPASSWORD)) {
            PreparedStatement st = con.prepareStatement("insert into sales (did, quantity, eventtime) values (?, ?, ?)");

            st.setInt(1, sale.getDid());
            st.setInt(2, sale.getQuantity());
            java.sql.Date drop = new java.sql.Date(sale.getEventtime().getTime());

            st.setDate(3, drop);

            st.executeUpdate();
            return true;
        } catch (Exception ex) {
            System.out.println(ex);
            return false;
        }
    }

    public static boolean insertPurchase(purchase p) {
        try (Connection con = DriverManager.getConnection(DBURL, DBUSER, DBPASSWORD)) {
            PreparedStatement st = con.prepareStatement("insert into purchase(did,date,qty) values (?,?,?)");
            st.setInt(1, p.getDid());
            java.sql.Date drop = new java.sql.Date(p.getDate().getTime());
            st.setDate(2, drop);
            st.setInt(3, p.getQty());
            st.executeUpdate();
            return true;
        } catch (Exception ex) {
            System.out.println(ex);
            return false;
        }
    }

    public static boolean insertExpiry(expiry e) {
        try (Connection con = DriverManager.getConnection(DBURL, DBUSER, DBPASSWORD)) {
            PreparedStatement st = con.prepareStatement("insert into expiry(did, date, expqty) values (?, ?, ?)");
            st.setInt(1, e.getDid());
            java.sql.Date drop = new java.sql.Date(e.getDate().getTime());
            st.setDate(2, drop);
            st.setInt(3, e.getExpiredQty());
            st.executeUpdate();
            return true;
        } catch (Exception ex) {
            System.out.println(ex);
            return false;
        }
    }

    public static int getRemQty(int did) {
        try (Connection con = DriverManager.getConnection(DBURL, DBUSER, DBPASSWORD)) {
            int qty = 0;
            PreparedStatement st = con.prepareStatement("select remqty from stockmanager where did = ?");
            st.setInt(1, did);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                qty = rs.getInt(1);
            }

            return qty;
        } catch (Exception ex) {
            System.out.println(ex);
            return 0;
        }
    }

    public static boolean incrementStock(int did, int qty) {
        try (Connection con = DriverManager.getConnection(DBURL, DBUSER, DBPASSWORD)) {
            PreparedStatement st = con.prepareStatement("update stockmanager set remqty = remqty + ? where did = ?");
            st.setInt(1, qty);
            st.setInt(2, did);
            st.executeUpdate();
            return true;
        } catch (Exception ex) {
            System.out.println(ex);
            return false;
        }
    }
    
    public static boolean decrementStock(int did, int qty) {
        try (Connection con = DriverManager.getConnection(DBURL, DBUSER, DBPASSWORD)) {
            PreparedStatement st = con.prepareStatement("update stockmanager set remqty = remqty - ? where did = ? and remqty >= ?");
            st.setInt(1, qty);
            st.setInt(2, did);
            st.setInt(3, qty);
            st.executeUpdate();
            return true;
        } catch (Exception ex) {
            System.out.println(ex);
            return false;
        }
    }

    public static boolean addStockManagerRow(int id) {
        try (Connection con = DriverManager.getConnection(DBURL, DBUSER, DBPASSWORD)) {
            PreparedStatement st = con.prepareStatement("insert into stockmanager (did) values (?)");

            st.setInt(1, id);

            st.executeUpdate();
            return true;
        } catch (Exception ex) {
            System.out.println(ex);
            return false;
        }
    }
    
    public static int getQuantityByDrugId(int did) {
        try (Connection con = DriverManager.getConnection(DBURL, DBUSER, DBPASSWORD)) {
            PreparedStatement st = con.prepareStatement("select remqty from stockmanager where did = ?");
            st.setInt(1, did);
            ResultSet rs = st.executeQuery();
            int qty = 0;
            while (rs.next()) {
                qty = rs.getInt(1);                
            }
            return qty;
        } catch (Exception ex) {
            System.out.println(ex);
            return -1;
        }
    }
    public static boolean checkIfDrugAlreadyExist(String dname, String cname){
            try (Connection con = DriverManager.getConnection(DBURL, DBUSER, DBPASSWORD)) {
            PreparedStatement st = con.prepareStatement("select id from drug where concat(name, company_name) in (?)");
            st.setString(1, dname.concat(cname));
            ResultSet rs = st.executeQuery();
            int ans=-1;
            if (rs.next()) {
                 ans = rs.getInt(1);                
            }
            return ans==-1?false:true;
        } catch (Exception ex) {
            System.out.println(ex);
            return true;
        }
    }
    
    public static ArrayList<Sales> getDrugSalesInYear(String drugname, String companyname, int year) {
        ArrayList<Sales> list = new ArrayList<>();
        try (Connection con = DriverManager.getConnection(DBURL, DBUSER, DBPASSWORD)) {
            PreparedStatement st1 = con.prepareStatement("select id from drug where name = ? and company_name = ?");
            st1.setString(1, drugname);
            st1.setString(2, companyname);
            ResultSet rs = st1.executeQuery();
            int id = -1;
            if (rs.next()) {
                id = rs.getInt(1);
            }
//            System.out.println(id);
            PreparedStatement st2 = con.prepareStatement("select sum(quantity), monthname(eventtime) from sales where did = ? and year(eventtime) = ? group by monthname(eventtime) order by eventtime");
            st2.setInt(1, id);
            st2.setInt(2, year);
//            System.out.println(st2);
            ResultSet rs2 = st2.executeQuery();
            while (rs2.next()) {
                Sales s = new Sales();
                s.setQuantity(rs2.getInt(1));
                s.setMonthname(rs2.getString(2));
                list.add(s);
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
        return list;
    }
}
