/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author S_H_R_E_Y
 */
import java.util.Date;
public class expiry {
    private int expiryid;
    private int did;
    private Date date;
    private int expiredQty;

    public int getExpiryid() {
        return expiryid;
    }

    public void setExpiryid(int expiryid) {
        this.expiryid = expiryid;
    }

    public int getDid() {
        return did;
    }

    public void setDid(int did) {
        this.did = did;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getExpiredQty() {
        return expiredQty;
    }

    public void setExpiredQty(int expiredQty) {
        this.expiredQty = expiredQty;
    }
    
}
