public class Launch {

    public static void main(String[] args) {
        MainFrame f = new MainFrame();
        f.setSize(1200, 1000);
        f.setVisible(true);
        f.setLocationRelativeTo(null);
    }
}
