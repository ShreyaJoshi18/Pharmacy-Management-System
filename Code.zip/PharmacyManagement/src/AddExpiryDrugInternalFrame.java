/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author S_H_R_E_Y
 */
public class AddExpiryDrugInternalFrame extends javax.swing.JInternalFrame {

    ArrayList<String> companyNames = new ArrayList<>();
    ArrayList<String> drugNames = new ArrayList<>();

    /**
     * Creates new form AddExpiryDrugInternalFrame
     */
    public AddExpiryDrugInternalFrame() {
        initComponents();
        drugNames = DBManager.getAllDrugs();
        showDrugNames();
    }

    private void showDrugNames() {
        for (String str : drugNames) {
            cbDrugName.addItem(str);
        }
    }

    private void resetForm() {
        txtExpiryQty.setText(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        cbDrugName = new javax.swing.JComboBox<>();
        cbCompanyName = new javax.swing.JComboBox<>();
        txtExpiryQty = new javax.swing.JTextField();
        spnDate = new javax.swing.JSpinner();
        btnSubmit = new javax.swing.JButton();
        btnReset = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        txtRemainingQty = new javax.swing.JTextField();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);

        jLabel1.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("DrugName");

        jLabel2.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("CompanyName");

        jLabel3.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("ExpiredQty");

        jLabel4.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Date");

        cbDrugName.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        cbDrugName.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbDrugNameItemStateChanged(evt);
            }
        });
        cbDrugName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbDrugNameActionPerformed(evt);
            }
        });

        cbCompanyName.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        cbCompanyName.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbCompanyNameItemStateChanged(evt);
            }
        });
        cbCompanyName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbCompanyNameActionPerformed(evt);
            }
        });

        txtExpiryQty.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N

        spnDate.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        spnDate.setModel(new javax.swing.SpinnerDateModel());
        spnDate.setEditor(new javax.swing.JSpinner.DateEditor(spnDate, "dd-MMM-yyyy"));

        btnSubmit.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        btnSubmit.setText("SUBMIT");
        btnSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSubmitActionPerformed(evt);
            }
        });

        btnReset.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        btnReset.setText("RESET");
        btnReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Current Qty");

        txtRemainingQty.setEditable(false);
        txtRemainingQty.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        txtRemainingQty.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtRemainingQtyActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(113, 113, 113)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnSubmit, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(120, 120, 120)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(cbDrugName, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cbCompanyName, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(spnDate)
                        .addComponent(txtRemainingQty)
                        .addComponent(btnReset, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtExpiryQty, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(131, 131, 131))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(50, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cbDrugName)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cbCompanyName, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtRemainingQty, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(2, 2, 2)
                        .addComponent(txtExpiryQty, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(spnDate, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(78, 78, 78)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSubmit, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnReset, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(52, 52, 52))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cbDrugNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbDrugNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbDrugNameActionPerformed

    private void btnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetActionPerformed
        resetForm();
    }//GEN-LAST:event_btnResetActionPerformed

    private void cbDrugNameItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbDrugNameItemStateChanged
        int drugIndex = cbDrugName.getSelectedIndex();
        String drugName = drugNames.get(drugIndex);
        companyNames = DBManager.getCompanyNamesByDrugName(drugName);
        showCompanyNames();
    }//GEN-LAST:event_cbDrugNameItemStateChanged

    private void btnSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubmitActionPerformed
        expiry e = new expiry();
        int drugIndex = cbDrugName.getSelectedIndex();
        String drugName = drugNames.get(drugIndex);
        int companyIndex = cbCompanyName.getSelectedIndex();
        String companyName = companyNames.get(companyIndex);
        int id = DBManager.getDrugIdByNameAndCompanyName(drugName, companyName);
        e.setDid(id);
        e.setDate((Date) spnDate.getValue());
        e.setExpiredQty(Integer.parseInt(txtExpiryQty.getText()));
        if (Integer.parseInt(txtExpiryQty.getText()) > Integer.parseInt(txtRemainingQty.getText())) {
            JOptionPane.showMessageDialog(this, "Please enter valid quantity!", "ERROR", JOptionPane.ERROR_MESSAGE);
        } else {
            boolean status = DBManager.insertExpiry(e);
            boolean decrementStock = DBManager.decrementStock(id, Integer.parseInt(txtExpiryQty.getText()));
            if (status) {
                JOptionPane.showMessageDialog(this, "Record has been saved !");
                resetForm();
            } else {
                JOptionPane.showMessageDialog(this, "Record has NOT been saved !", "ERROR", JOptionPane.ERROR_MESSAGE);
            }
        }

    }//GEN-LAST:event_btnSubmitActionPerformed

    private void cbCompanyNameItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbCompanyNameItemStateChanged
        int drugIndex = cbDrugName.getSelectedIndex();
        String drugName = drugNames.get(drugIndex);
        int companyIndex = cbCompanyName.getSelectedIndex();
        String companyName = companyNames.get(companyIndex);
        int qty = DBManager.getQuantityByDrugId(DBManager.getDrugIdByNameAndCompanyName(drugName, companyName));
        txtRemainingQty.setText(qty + "");
    }//GEN-LAST:event_cbCompanyNameItemStateChanged

    private void txtRemainingQtyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtRemainingQtyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtRemainingQtyActionPerformed

    private void cbCompanyNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbCompanyNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbCompanyNameActionPerformed
    private void showCompanyNames() {
        cbCompanyName.removeAllItems();
        for (String name : companyNames) {
            cbCompanyName.addItem(name);

        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnReset;
    private javax.swing.JButton btnSubmit;
    private javax.swing.JComboBox<String> cbCompanyName;
    private javax.swing.JComboBox<String> cbDrugName;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JSpinner spnDate;
    private javax.swing.JTextField txtExpiryQty;
    private javax.swing.JTextField txtRemainingQty;
    // End of variables declaration//GEN-END:variables
}
