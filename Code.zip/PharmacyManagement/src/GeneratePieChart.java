import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
//import org.jfree.chart.labels.PieSectionLabelGenerator;
import org.jfree.data.general.DefaultPieDataset;
//import org.jfree.chart.labels.StandardPieSectionLabelGenerator;


public class GeneratePieChart {
    String title;
    public GeneratePieChart(ArrayList<Sales> list, String title) throws IOException, InterruptedException {
        this.title = title;
        showPieChart(list);
    }
    
    private void showPieChart(ArrayList<Sales> list) throws IOException, InterruptedException {
        //final PieSectionLabelGenerator labelGenerator = new StandardPieSectionLabelGenerator("{0} = {1}");
        DefaultPieDataset dataset = new DefaultPieDataset();
        int i = 0;
        while (i < list.size()) {
            Sales e = list.get(i);

            dataset.setValue(e.getMonthname(), e.getQuantity());
            i++;
        }
        JFreeChart chart = ChartFactory.createPieChart(
                title,
                dataset,
                true,
                true,
                false
        );
       
        int width = 800;
        int height = 600;
        File pieChart = new File("pie_chart.jpeg");
        ChartUtilities.saveChartAsJPEG(pieChart, chart, width, height);

        String fileName = "C:\\Users\\S_H_R_E_Y\\Documents\\NetBeansProjects\\PharmacyManagement\\pie_chart.jpeg";
        File f = new File(fileName);
        Desktop dt = Desktop.getDesktop();
        dt.open(f);
    }
}
